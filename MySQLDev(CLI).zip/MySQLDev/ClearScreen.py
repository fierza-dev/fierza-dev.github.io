import os
from os import system, name

def clear_screen():
    if os.name == "nt":
        system("cls")
    else:
        system("clear")