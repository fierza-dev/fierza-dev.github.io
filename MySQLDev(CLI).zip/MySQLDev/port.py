import socket
from settings import *

create_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

destination = ("127.0.0.1", 80)
result = create_socket.connect_ex(destination)

if result != 0:
    print("[ X ] Error: XAMPP is not active or port 3306 is not active...")
    config.set("Configure", "localhost", 'OFF')
    with open(CONFIG_FILE_PATH, 'w') as configfile:
        config.write(configfile)
else:
    config.set("Configure", "localhost", 'ON')
    with open(CONFIG_FILE_PATH, 'w') as configfile:
         config.write(configfile)
create_socket.close()