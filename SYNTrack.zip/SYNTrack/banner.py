def banner():
    print("""
 _______   __   ___  _____              _             
/  ___\ \ / / \ | | |_   _|            | |            
\ `--. \ V /|  \| |   | |_ __ __ _  ___| | _____ _ __ 
 `--. \ \ / | . ` |   | | '__/ _` |/ __| |/ / _ \ '__|
/\__/ / | | | |\  |   | | | | (_| | (__|   <  __/ |   
\____/  \_/ \_| \_/   \_/_|  \__,_|\___|_|\_\___|_| V1.0 Release
    
Mendeteksi SYN Pocket Dari Pengguna Yang Mengakses Dan deteksi Serangan SYN Flood
    """)

banner()