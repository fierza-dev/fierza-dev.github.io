<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tokopedei Search Engine</title>
    <link rel="stylesheet" href="assets/css/import.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
      .nama{
        margin-left: -43% !important;
      }
    </style>
  </head>
  <body>
    <div class="container-sm">
        <!-- menu -->
        <nav class="navbar bg-transperent">
          <div class="container-fluid">
            <a class="navbar-brand"></a>
            <button class="btn btn-outline-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"><b><i class="bi bi-list"></b></i></button>
            <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
              <div style="background-image: url(assets/img/bg/back.jpg);background-repeat: no-repeat;background-size:cover;" class="offcanvas-header">
                <center><img src="assets/img/logo/pdi.jpg" width="100" height="100" class="shadow rounded" alt="..."></center>
                <span>
                  <br>
                  <p class="nama"><b>M.Fierza Eries Erlangga</b><br><span class="text-secondary">INF22004</span><br><span class="text-secondary">Informatika</span></p>
                </span>
              </div>
              <div class="offcanvas-body">
                <p></p>
              </div>
            </div>  
          </div>
        </nav>
        <center>
          <br>
          <img src="assets/img/logo/pdi.jpg" width="200" height="200" class="mb-3 rounded img-fluid" alt="...">
          <form method="post">
            <div class="container-sm mt-n5">
              <div class="form-floating mb-3">
                <input type="text" name="keyword" class="rounded-pill form-control" id="floatingInput" placeholder="name@example.com">
                <label for="floatingInput">Masukkan Kata keywordnya....</label>
              </div>
            </div>
          </form>
        </center>
        <?php 
            if(isset($_POST['keyword'])){
              $ListKeyword = explode(" ",$_POST['keyword']);
              
              $word = preg_split("/ /",$_POST['keyword']);
              for($i=0;$i<=count($word)-1;$i++){
                $sim=similar_text($word[$i],$word[$i],$percent);
                $dis = levenshtein($word[$i],$word[$i]);
              }
              $percent = round($percent, 2);
              echo "<b>Kata</b> : ".implode(" & ",$word)."<br>";
              echo "<b>Similarity</b> : ".$sim."<br>";
              echo "<b>Edit Distance : </b>".$dis;
            }
        ?>
    </div>

    <!-- footer -->
    <footer id="sticky-footer" class="fixed-bottom flex-shrink-0 py-4 bg-dark text-white-50">
      <div class="container text-center">
        <small>Copyright &copy; Tokopedei</small>
      </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
