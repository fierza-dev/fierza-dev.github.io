import configparser

config = configparser.ConfigParser()
config['MYSQL'] = {
    'host': 'localhost',
    'username': 'root',
    'password': '',
    'database': ''
}

config['StatusConf']={
    'Status' : 'True'
}

config['Configure'] = {
    'path': 'your_url_WebBased',
    'localhost' : 'OFF',
}

with open('dist/config/config.ini', 'w') as configfile:
    config.write(configfile)
