import subprocess
from GetConfIni import *
from InquirerPy import prompt, inquirer

def SetConf():
    try:
        questions = [
            {
                'type': 'list',
                'name': 'SetConf',
                'message': 'Settings Config : ',
                'choices': [
                    'IP',
                    'PORT',
                    'Back To Menu'
                ]
            }
        ]

        answers = prompt(questions)

        if answers['SetConf'] == 'IP':
            SetHost = inquirer.text(message=f"Set IP Server > ").execute()
            config.set('SERVER', 'IP', SetHost)
            with open(CONFIG_FILE_PATH, 'w') as configfile:
                config.write(configfile)
            print("[ ! ] Successful IP Change...")
            SetConf()
        elif answers['SetConf'] == 'PORT':
            SetHost = inquirer.text(message=f"Set Port Server > ").execute()
            config.set('SERVER', 'PORT', SetHost)
            with open(CONFIG_FILE_PATH, 'w') as configfile:
                config.write(configfile)
            print("[ ! ] Successful Port Change...")
            SetConf()
        elif answers['SetConf'] == 'Back To Menu':
            subprocess.run("python3 main.py", shell=True, check=True)
            
    except KeyboardInterrupt:
        choice = True
        choice = inquirer.confirm(message="Do you want to exit??", default=False).execute()
        if choice:
            print("[ >_< ] Good Bye....")
            exit()
        else:
            subprocess.run("python3 main.py", shell=True, check=True)