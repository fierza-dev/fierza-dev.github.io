import os

def set_terminal_title(title):
    if os.name == 'posix':
        # For Unix (Linux/macOS) terminals
        print(f'\033]0;{title}\007', end='', flush=True)
    elif os.name == 'nt':
        # For Windows terminals
        os.system(f'title {title}')