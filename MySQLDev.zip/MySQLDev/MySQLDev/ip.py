import subprocess

def fix_mysql_access_denied_error(db_config):
    try:
        commands = [
            "UPDATE user SET plugin='mysql_native_password' WHERE User='root';",
            "FLUSH PRIVILEGES;",
            "exit;"
        ]
        for command in commands:
            subprocess.run(['mysql', '-u', db_config['user'], '-p', db_config['password'],"-D",db_config["database"], '-h', db_config['host'], '-e', command], check=True)
        subprocess.run(['sudo', 'service', 'mysql', 'restart'], check=True)
        print("MySQL user 'root'@'localhost' updated successfully.")
    except subprocess.CalledProcessError as sub_error:
        print("Error:", sub_error)
        print("Failed to update MySQL user 'root'@'localhost'. Please check the MySQL logs for more details.")

if __name__ == "__main__":
    db_config = {
        "user": "root",  # Update with your MySQL username
        "password": "root",  # Update with your MySQL password
        "host": "localhost",  # Update with your MySQL host
        "database" : "mysql"
        # Add other necessary connection parameters here (e.g., port, database, etc.)
    }

    print("Attempting to fix MySQL access denied error...")
    fix_mysql_access_denied_error(db_config)
