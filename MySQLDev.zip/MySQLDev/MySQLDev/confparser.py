import configparser

config = configparser.ConfigParser()
# config['MYSQL'] = {
#     'host': 'localhost',
#     'username': 'root',
#     'password': '',
#     'database': ''
# }

# config['StatusConf']={
#     'Status' : 'True'
# }

# config['Configure'] = {
#     'path': 'your_url_WebBased',
#     'localhost' : 'OFF',
# }

config['SERVER'] ={
    'IP' :'39.149.100.209',
    'POST' : '80',
}

with open('../SYNTrack/src/config/config.ini', 'w') as configfile:
    config.write(configfile)
