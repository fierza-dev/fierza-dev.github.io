import subprocess
from track import *
from setting import *
from InquirerPy import prompt, inquirer

def menu():
    try:
        questions = [
            {
                'type': 'list',
                'name': 'menu',
                'message': 'Menu : ',
                'choices': [
                    'Track Now',
                    'Setting',
                    'Exit'
                ]
            }
        ]

        answers = prompt(questions)

        if answers['menu'] == 'Track Now':
            trackSYN()
        elif answers['menu'] == 'Setting':
            SetConf()
            exit()
        elif answers['menu'] == 'Exit':
            print("[ >_< ] Good Bye....")
            exit()
    except KeyboardInterrupt:
        hoice = True
        choice = inquirer.confirm(message="Do you want to exit??", default=False).execute()
        if choice:
            print("[ >_< ] Good Bye....")
            exit()
        else:
            subprocess.run("python3 main.py", shell=True, check=True)

menu()
