#!/usr/local/bin/python
import os
import re
import sys
import time
import threading
import mysql.connector
from port import *
from banner import *
from settings import *
from os import system, name
from prettytable import PrettyTable
from ClearScreen import clear_screen
from InquirerPy import prompt, inquirer
from terminalTitle import set_terminal_title

def show_tables(cursor, results):
    if cursor.rowcount == 0:
        print("[ X ] Empty set...")

    my_table = PrettyTable([f"Tables_in_{config.get('MYSQL', 'database')}"])
    for data in results:
        new_data = re.sub(r'[(),\']', '', str(data))
        my_table.add_row([new_data])

    my_table.align = 'l'
    print(my_table)


def desc_tables(cursor, results, query):
    list_q = query.split(' ')
    print("[ + ] Table Name : " + list_q[1])
    column_names = [i[0] for i in cursor.description]

    table = PrettyTable(column_names)

    for row in results:
        table.add_row(row)

    table.align = "l"
    print(table)


def show_databases(results):
    my_table = PrettyTable(["Database"])
    for data in results:
        new_data = re.sub(r'[(),\']', '', str(data))
        my_table.add_row([new_data])
    my_table.align = 'l'
    print(my_table)


def change_database(query, config):
    list_q = query.split(' ')
    config.set('MYSQL', 'database', list_q[1])
    with open(CONFIG_FILE_PATH, 'w') as configfile:
        config.write(configfile)
        print("Database changed....")


def select_from(results, cursor, query):
    list_q = query.split(' ')
    print("[ + ] Table Name : " + list_q[3])
    column_names = [i[0] for i in cursor.description]

    table = PrettyTable(column_names)

    for row in results:
        table.add_row(row)

    table.align = "l"
    print(table)


def insert_into(cursor, results, query):
    print('Query OK, 1 row affected..')


def get_input(cursor):
    my_table = ''
    if config.get('MYSQL', 'database') == '':
        query = inquirer.text(message="MySQLDev [(none)]> ").execute()
    else:
        query = inquirer.text(message=f"MySQLDev [({config.get('MYSQL', 'database')})]> ").execute()

    if query.lower() == 'exit' or query.lower() == 'quit':
        main()
    try:
        cursor.execute(query)
        results = cursor.fetchall()

        if query.upper() == "SHOW DATABASES":
            show_databases(results)
        elif re.match('USE', query.upper()):
            change_database(query, config)
        elif query.upper() == "SHOW TABLES":
            show_tables(cursor, results)
        elif re.match("SELECT", query.upper()):
            select_from(results, cursor, query)
        elif re.match('DESC', query.upper()):
            desc_tables(cursor, results, query)
        elif re.match('INSERT', query.upper()):
            insert_into(cursor, results, query)

        get_input(cursor)
    except Exception as err:
        print(f'{err}')
        get_input(cursor)
    

def settings():
    questions = [
        {
            'type': 'list',
            'name': 'Settings',
            'message': 'Settings : ',
            'choices': [
                'Set Config',
                'Back To Menu'
            ]
        }
    ]

    answers = prompt(questions)

    if answers['Settings'] == 'Set Config':
        SetConf()
    elif answers['Settings'] == 'Back To Menu':
        main()

def SetConf():
    questions = [
        {
            'type': 'list',
            'name': 'SetConf',
            'message': 'Settings Config : ',
            'choices': [
                'Host',
                'Username Database',
                'Password Database',
                'Database Name',
                'Back To Menu'
            ]
        }
    ]

    answers = prompt(questions)

    if answers['SetConf'] == 'Host':
         SetHost = inquirer.text(message=f"Set Host > ").execute()
         config.set('MYSQL', 'host', SetHost)
         with open(CONFIG_FILE_PATH, 'w') as configfile:
            config.write(configfile)
         print("[ ! ] Successful Host Change...")
         SetConf()
    elif answers['SetConf'] == 'Username Database':
         SetUser = inquirer.text(message=f"Set Username Database > ").execute()
         config.set('MYSQL', 'username', SetUser)
         with open(CONFIG_FILE_PATH, 'w') as configfile:
            config.write(configfile)
         print("[ ! ] Successful Host Change...")
         SetConf()
    elif answers['SetConf'] == 'Password Database':
         SetPass = inquirer.text(message=f"Set Password Database > ").execute()
         config.set('MYSQL', 'password', SetPass)
         with open(CONFIG_FILE_PATH, 'w') as configfile:
            config.write(configfile)
         print("[ ! ] Successful Host Change...")
         SetConf()
    elif answers['SetConf'] == 'Database Name':
         SetPass = inquirer.text(message=f"Set Database Name > ").execute()
         config.set('MYSQL', 'database', SetPass)
         with open(CONFIG_FILE_PATH, 'w') as configfile:
            config.write(configfile)
         print("[ ! ] Successful Host Change...")
         SetConf()
    elif answers['SetConf'] == 'Back To Menu':
        main()


def connect(db_config):
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        get_input(cursor)
    except mysql.connector.Error as error:
        print(f"Error: {error}")


def main():
    set_terminal_title("MySQLDev V1.0 (Beta)")
    clear_screen()
    banner()
    questions = [
        {
            'type': 'list',
            'name': 'menu',
            'message': 'Menu:',
            'choices': [
                'Desktop [ Development ]',
                'Web Based [ Development ]',
                'Command Line Interface',
                'Settings',
                'Exit'
            ]
        }
    ]

    answers = prompt(questions)

    if answers['menu'] == 'Desktop':
        print("This feature is still in development....")
    elif answers['menu'] == 'Web Based':
        print("This feature is still in development....")
    elif answers['menu'] == 'Command Line Interface':
        if config.get('Configure', 'localhost') != 'OFF':
            connect(db_config)
        print("[ ! ] Harap Nyalakan XAMPP Terlebih Dahulu...")
        time.sleep(1.4)
        main()
    elif answers['menu'] == 'Settings':
        settings()
    elif answers['menu'] == 'Exit':
        print("See You :)")
        sys.exit(0)


if __name__ == '__main__':
    main()
