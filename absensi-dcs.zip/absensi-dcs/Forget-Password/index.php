<?php 
    include('../koneksi/conf.php');
    session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forget Password</title>
    <link rel="stylesheet" href="../assets/css/import.css">
    <link rel="stylesheet" href="../assets/css/forget-password.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="mt-5 center-card">
        <div class="shadow card border-dark mb-3" style="width: 30rem;">
            <div class="card-header"><i class="bi bi-backspace-reverse-fill"></i> Lupa Password</div>
            <div class="card-body text-dark">
                <form method="post">
                    <div class="form-floating mb-3">
                        <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Email address</label>
                    </div>
                    <center>
                        <button type="button" class="btn btn-success"><i class="bi bi-house-door-fill"></i> Back To Home</button>
                        <button type="submit" name="reset" width="100%" class="btn btn-outline-dark w-full"><i class="bi bi-back"></i> Reset Now</button>
                    </center>
                </form>
                <?php 
                    if(isset($_POST['reset'])){
                        $email = $_POST['email'];
                        $result = mysqli_query($conn,"select * from UserPegawai where email='$email'");
                        if ($result->num_rows > 0) {
                            $row = mysqli_fetch_assoc($result);
                            $_SESSION['email'] = $row['email'];
                            echo "<script>window.location='Reset-Password'</script>";
                        } else {
                            echo "<script>alert('Email Anda Tidak Cocok')</script>";
                        }
                    }
                ?>
            </div>
        </div>      
    </div>
    <!-- footer -->
    <div class="container-fluid">
        <footer id="sticky-footer" class="fixed-bottom flex-shrink-0 py-4 bg-dark text-white-50">
            <div class="container text-center">
            <small>Copyright &copy; <a href="https://dcsmedika.com/" class="pe-auto text-decoration-none text-white-50">Dimensi Citra Semesta</a></small>
            </div>
        </footer>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
