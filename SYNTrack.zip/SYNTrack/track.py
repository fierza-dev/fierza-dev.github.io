import time
import subprocess
from scapy.all import *
from GetConfIni import *

def trackSYN():
    try:
        tcp = f"ip host {config.get('SERVER', 'ip')}"
        def PacketCallback(packet):
            tgl = time.strftime("%m/%d/%Y", time.localtime())
            waktu = time.strftime("%H:%M:%S", time.localtime())

            if packet.haslayer(TCP) and packet[TCP].flags & 0x02:
                print(f"[ ! ] {tgl} {waktu} | Detected SYN packet from {packet[IP].src}")
            
        sniff(filter=tcp, prn=PacketCallback)
    except KeyboardInterrupt:
        choice = True
        choice = inquirer.confirm(message="Do you want to exit??", default=False).execute()
        if choice:
            print("[ >_< ] Good Bye....")
            exit()
        else:
            subprocess.run("python3 main.py", shell=True, check=True)