#!/usr/local/bin/python
import configparser
import os

directory = os.getcwd()

# Constants
CONFIG_FILE_PATH = f'{directory}/src/config/config.ini'

# Load configuration from config.ini
config = configparser.ConfigParser()
config.read(CONFIG_FILE_PATH)

