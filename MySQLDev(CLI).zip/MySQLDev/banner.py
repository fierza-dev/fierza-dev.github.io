from settings import *

def banner():
    pesan = ""
    LHOST = ""
    
    #Status StatusConf
    if db_config['host'] == '' or db_config['user'] == '' or db_config['database'] == '':
        pesan = "[ ✕ ] Config Database"
    else:
        pesan = "[ ✓ ] Config Database"
    
    #status LHOST
    if config.get('Configure', 'localhost') == 'OFF':
        LHOST = "[ ✕ ] XAMPP"
    else:
        LHOST = "[ ✓ ] XAMPP"
    
    print(f"""
 © 2023 FierzaDev™. All Rights Reserved.         
 ____    ____         ______    ___     _____    ______                 
|_   \  /   _|      .' ____ \ .'   `.  |_   _|  |_   _ `.               
  |   \/   |   _   _| (___ \_/  .-.  \   | |      | | `. \.---. _   __  
  | |\  /| |  [ \ [  _.____`.| |   | |   | |   _  | |  | / /__\[ \ [  ] 
 _| |_\/_| |_  \ '/ | \____) \  `-'  \_ _| |__/ |_| |_.' | \__.,\ \/ /  
|_____||_____[\_:  / \______.'`.___.\__|________|______.' '.__.' \__/  V1.0 (Beta)
              \__.'                                             
 
 *Harap Pastikan Salah Satu Requirement ON
 Requirement :
   {LHOST}
   {pesan}
 """)