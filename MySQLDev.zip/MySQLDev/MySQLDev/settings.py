#!/usr/local/bin/python
import configparser
import os

directory = os.getcwd()

# Constants
CONFIG_FILE_PATH = f'{directory}/dist/config/config.ini'

# Load configuration from config.ini
config = configparser.ConfigParser()
config.read(CONFIG_FILE_PATH)


db_config = {
    'host': config.get('MYSQL', 'host'),
    'user': config.get('MYSQL', 'username'),
    'password': config.get('MYSQL', 'password'),
    'database': config.get('MYSQL', 'database'),
}

