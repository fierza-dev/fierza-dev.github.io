<?php
$server = "localhost";
$userdb = "root";
$passdb = "";
$database = "AbsensiDCS";

$conn = mysqli_connect($server,$userdb,$passdb,$database);

if(!$conn){
    echo "Database Tidak Terkoneksi";
}